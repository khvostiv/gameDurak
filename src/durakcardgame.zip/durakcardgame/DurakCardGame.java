package durakcardgame;

import java.util.Scanner;

public class DurakCardGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to Durak!");

        System.out.print("Enter number of players (2-6): ");
        int numPlayers = scanner.nextInt();
        while (numPlayers < 2 || numPlayers > 6) {
            System.out.print("Invalid number. Enter players (2-6): ");
            numPlayers = scanner.nextInt();
        }

        String[] playerNames = new String[numPlayers];
        for (int i = 0; i < numPlayers; i++) {
            System.out.print("Enter name for Player " + (i + 1) + ": ");
            playerNames[i] = scanner.next();
        }

        DurakGame game = new DurakGame("Durak", playerNames);
        game.play();
    }
}
