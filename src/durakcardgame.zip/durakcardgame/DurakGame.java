package durakcardgame;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class DurakGame extends Game {
    private Deck deck;
    private Card trumpCard;
    private int attackerIndex;
    private int defenderIndex;
    private ArrayList<Card> tableCards;
    private boolean defenderSkipped = false;

    public DurakGame(String name, String[] playerNames) {
        super(name);
        this.deck = new Deck();
        this.deck.shuffle();
        this.trumpCard = deck.drawCard();
        deck.addTrumpCardBack(trumpCard);
        System.out.println("Trump card: " + trumpCard);
        System.out.println("Trump suit: " + trumpCard.getSuit());

        this.tableCards = new ArrayList<>();

        for (String playerName : playerNames) {
            addPlayer(new DurakPlayer(playerName));
        }

        for (Player player : getPlayers()) {
            DurakPlayer p = (DurakPlayer) player;
            for (int j = 0; j < 6; j++) {
                p.takeCard(deck.drawCard());
            }
        }

        determineFirstAttacker();
    }

private void determineFirstAttacker() {
    Card smallestTrump = null; // Самая маленькая козырная карта
    DurakPlayer firstAttacker = null; // Игрок с самой маленькой козырной картой

    // Перебираем всех игроков
    for (Player player : getPlayers()) {
        DurakPlayer durakPlayer = (DurakPlayer) player;
        for (Card card : durakPlayer.getHand()) {
            // Проверяем только карты козырной масти
            if (card.getSuit().equals(trumpCard.getSuit())) {
                // Находим карту с наименьшим значением
                if (smallestTrump == null || card.getRankValue() < smallestTrump.getRankValue()) {
                    smallestTrump = card;
                    firstAttacker = durakPlayer;
                }
            }
        }
    }

    if (firstAttacker != null) {
        attackerIndex = getPlayers().indexOf(firstAttacker);
        defenderIndex = (attackerIndex + 1) % getPlayers().size();
        System.out.println(firstAttacker.getName() + " is the first attacker with " + smallestTrump);
    } else {
        // Если козырных карт нет
        attackerIndex = 0;
        defenderIndex = 1;
        System.out.println(getPlayers().get(attackerIndex).getName() + " is the first attacker by default.");
    }
}



    @Override
    public void play() {
        Scanner scanner = new Scanner(System.in);

        while (!isGameOver()) {
            displayCurrentHands();

            DurakPlayer attacker = (DurakPlayer) getPlayers().get(attackerIndex);
            DurakPlayer defender = (DurakPlayer) getPlayers().get(defenderIndex);

            if (defenderSkipped) {
                defenderSkipped = false;
                attackerIndex = (attackerIndex + 1) % getPlayers().size();
                defenderIndex = (attackerIndex + 1) % getPlayers().size();
                continue;
            }

            System.out.println(attacker.getName() + " is attacking " + defender.getName() + ".");
            tableCards.clear();

            boolean roundInProgress = true;

            while (roundInProgress) {
                if (tableCards.size() % 2 == 0) { // Attacker's turn
                    System.out.println(attacker.getName() + "'s hand: " + attacker.showHand());
                    System.out.println("Cards on the table: " + tableCards);
                    System.out.print(attacker.getName() + ", choose a card to attack with (index, or -1 to skip): ");
                    int attackIndex = scanner.nextInt();

                    if (attackIndex == -1) {
                        System.out.println(attacker.getName() + " ends their attack.");
                        allowOthersToAddCards(scanner, defender);
                        roundInProgress = false;
                        break;
                    }

                    Card attackCard = attacker.playCard(attackIndex);
                    if (attackCard == null) {
                        System.out.println("Invalid card! Try again.");
                    } else {
                        tableCards.add(attackCard);
                    }
                }

if (tableCards.size() % 2 != 0 && !defenderSkipped) { // Defender's turn
    while (true) { // Loop until valid defense or the defender picks up
        System.out.println("Cards on the table: " + tableCards);
        System.out.println(defender.getName() + "'s hand: " + defender.showHand());
        System.out.print(defender.getName() + ", choose a card to defend with (index, or -1 to pick up): ");
        int defendIndex = scanner.nextInt();

        if (defendIndex == -1) { // Defender gives up
            System.out.println(defender.getName() + " picks up all cards.");
            defender.takeCards(new ArrayList<>(tableCards)); // Add all table cards to defender's hand
            tableCards.clear();
            defenderSkipped = true;
            askOtherPlayersToAddCards(scanner, defender); // Ask other players to add cards
            roundInProgress = false;
            break;
        }

        Card defendCard = defender.playCard(defendIndex);
        if (isValidDefense(tableCards.get(tableCards.size() - 1), defendCard)) { // Valid defense
            System.out.println("Successful defense!");
            tableCards.add(defendCard);
            break; // Break loop if successful defense
        } else {
            System.out.println("Invalid defense card! Try again.");
            if (defendCard != null) {
                defender.takeCard(defendCard); // Return invalid card to hand
            }
        }
    }
}


            }

            refillAllHands();
            attackerIndex = (attackerIndex + 1) % getPlayers().size();
            defenderIndex = (attackerIndex + 1) % getPlayers().size();
        }

        declareWinner();
    }
private void allowOthersToAddCards(Scanner scanner, DurakPlayer defender) {
    boolean cardsAdded = false;
    Set<Player> alreadyAsked = new HashSet<>();

    for (Player player : getPlayers()) {
        if (player != defender && !alreadyAsked.contains(player)) {
            DurakPlayer addingPlayer = (DurakPlayer) player;
            System.out.println("Cards on the table: " + tableCards);
            System.out.println(addingPlayer.getName() + "'s hand: " + addingPlayer.showHand());
            System.out.print(addingPlayer.getName() + ", do you want to add a card? (index, or -1 to skip): ");
            int throwIndex = scanner.nextInt();

            if (throwIndex == -1) {
                alreadyAsked.add(addingPlayer);
                continue;
            }

            Card throwCard = addingPlayer.playCard(throwIndex);
            if (throwCard != null && isValidThrow(throwCard)) {
                tableCards.add(throwCard);
                cardsAdded = true;
                System.out.println("Cards on the table: " + tableCards);
            } else {
                System.out.println("Invalid card for throwing! Try again.");
                if (throwCard != null) {
                    addingPlayer.takeCard(throwCard);
                }
            }
        }
    }

    if (!cardsAdded) {
        System.out.println("No additional cards were added.");
    }
}

private void askOtherPlayersToAddCards(Scanner scanner, DurakPlayer defender) {
    boolean cardsAdded = false;
    Set<Player> alreadyAsked = new HashSet<>();

    for (Player player : getPlayers()) {
        if (player != defender && !alreadyAsked.contains(player)) {
            DurakPlayer addingPlayer = (DurakPlayer) player;
            System.out.println(addingPlayer.getName() + "'s hand: " + addingPlayer.showHand());
            System.out.println("Cards on the table: " + tableCards);
            System.out.print(addingPlayer.getName() + ", do you want to add a card? (index, or -1 to skip): ");
            int throwIndex = scanner.nextInt();

            if (throwIndex == -1) {
                alreadyAsked.add(addingPlayer);
                continue;
            }

            Card throwCard = addingPlayer.playCard(throwIndex);
            if (throwCard != null && isValidThrow(throwCard)) {
                tableCards.add(throwCard);
                cardsAdded = true;
                System.out.println("Cards on the table: " + tableCards);
            } else {
                System.out.println("Invalid card for throwing! Try again.");
                if (throwCard != null) {
                    addingPlayer.takeCard(throwCard);
                }
            }
        }
    }

    if (!cardsAdded) {
        System.out.println("No additional cards were added.");
    }
}


    private void displayCurrentHands() {
        System.out.println("\n--- Current Hands ---");
        for (Player player : getPlayers()) {
            DurakPlayer durakPlayer = (DurakPlayer) player;
            System.out.println(durakPlayer.getName() + "'s hand: " + durakPlayer.showHand());
        }
        System.out.println("Trump card: " + trumpCard);
        System.out.println("---------------------");
    }

    @Override
    public void declareWinner() {
        System.out.println("Game over!");
        for (Player player : getPlayers()) {
            if (((DurakPlayer) player).getHandSize() > 0) {
                System.out.println(player.getName() + " is the Durak (loser)!");
                return;
            }
        }
    }

    private boolean isValidDefense(Card attackCard, Card defendCard) {
        return defendCard != null &&
                ((defendCard.getSuit().equals(attackCard.getSuit()) && defendCard.getRankValue() > attackCard.getRankValue())
                        || defendCard.getSuit().equals(trumpCard.getSuit()));
    }

    private boolean isValidThrow(Card card) {
        for (Card tableCard : tableCards) {
            if (tableCard.getRank().equals(card.getRank())) {
                return true;
            }
        }
        return false;
    }

    private void refillAllHands() {
        for (Player player : getPlayers()) {
            DurakPlayer durakPlayer = (DurakPlayer) player;
            while (durakPlayer.getHandSize() < 6 && !deck.isEmpty()) {
                durakPlayer.takeCard(deck.drawCard());
            }
        }
    }

    @Override
    public boolean isGameOver() {
        int playersWithCards = 0;
        for (Player player : getPlayers()) {
            if (((DurakPlayer) player).getHandSize() > 0) {
                playersWithCards++;
            }
        }
        return playersWithCards <= 1;
    }
}
