package durakcardgame;

import java.util.ArrayList;

public abstract class Game {
    private final String name; // Name of the game
    private ArrayList<Player> players; // List of players

    public Game(String name) {
        this.name = name;
        this.players = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public abstract void play();

    public abstract void declareWinner();

    public abstract boolean isGameOver();
}
