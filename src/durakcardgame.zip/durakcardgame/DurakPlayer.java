package durakcardgame;

import java.util.ArrayList;

public class DurakPlayer extends Player {
    private ArrayList<Card> hand;

    public DurakPlayer(String name) {
        super(name);
        this.hand = new ArrayList<>();
    }

    public void takeCard(Card card) {
        hand.add(card);
    }

    public void takeCards(ArrayList<Card> cards) {
        hand.addAll(cards);
    }

    public Card playCard(int index) {
        if (index >= 0 && index < hand.size()) {
            return hand.remove(index);
        }
        return null;
    }

    public int getHandSize() {
        return hand.size();
    }

    public ArrayList<Card> getHand() {
        return hand;
    }

    public String showHand() {
        return hand.toString();
    }

    @Override
    public void play() {
        // Not needed for this implementation
    }
}
